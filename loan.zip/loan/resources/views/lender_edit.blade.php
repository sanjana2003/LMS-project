<!DOCTYPE html>
<html>
    <head>
        <title>Lender Management | Edit</title>
        <style>
            body{
                background-image:url(/images/edit.jpeg);
                font-family:Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }
            h1{
                text-align: center;
            }
            form {
              
    width: 300px;
    margin: 100px auto; /* Set auto for left and right margins to center the form */
    background-color: #fff;
    border: 1px solid #ccc;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

            table{
                width: 100%;
            }
            table tr{
                margin-bottom: 10px;
            }
            td{
                padding: 10px;
                text-align: right;
            }
            input[type="text"]{
                width: 100%;
                padding: 5px;
            }

            input[type="submit"]{
                background-color: #007BFF;
                color: #fff;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
            }
            input[type="submit"]:hover{
                 background-color: #0056b3;
            }
        </style>
    </head>
    <body>
        <form action="/edit1/{$lender[0]->id }}" method="post">
           @csrf
           <h1>Edit Form</h1>
           <table>
              <tr>
                <td>Name</td>
                <td><input type="text" name="name" value="{$lender[0]->name }}" /></td>
              </tr>

              <tr>
                <td>Email</td>
                <td><input type="text" name="email" value="{$lender[0]->email }}" /></td>
              </tr>
              <tr>
                <td>age</td>
                <td><input type="text" name="age" value="{$lender[0]->age }}" /></td>
              </tr>
              <tr>
                <td>ph</td>
                <td><input type="text" name="ph" value="{$lender[0]->ph }}" /></td>
              </tr>
              <tr>
                <td>Qualification</td>
                <td><input type="text" name="qualification" value="{$lender[0]->qualification }}" /></td>
              </tr>
              <tr>
                <td>address</td>
                <td><input type="text" name="address" value="{$lender[0]->address }}" /></td>
              </tr>
              <tr>
                <td>accno</td>
                <td><input type="text" name="accno" value="{$lender[0]->accno }}" /></td>
              </tr>
              <tr>
                <td>branch</td>
                <td><input type="text" name="branch" value="{$lender[0]->branch }}" /></td>
              </tr>
              <tr>
                <td>salary</td>
                <td><input type="text" name="salary" value="{$lender[0]->salary }}" /></td>
              </tr>

              
            

              <tr>
                <td colspan="2">
                    <input type="submit" value="update lender" />
                </td>
              </tr>
            </table>
        </form>
    </body>
</html>