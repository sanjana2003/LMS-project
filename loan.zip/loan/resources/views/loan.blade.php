<!DOCTYPE html>
<html>
<head>
    <title>Loan successfully applied</title>
    <style>
       body {
            background-image: url('https://i.pinimg.com/originals/6b/1b/a2/6b1ba2f73c7bbac431870aeb63ac39af.png');
            background-size: cover;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }