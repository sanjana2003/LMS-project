<!DOCTYPE html>
<html>
<head>
    <title>Lender Details</title>
    <style>
       body {
            background-image: url(/images/list.jpeg);
            background-size: cover;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-top: 20px;
        }

        table {
            width: 80%; /* Center the table and control its width */
            margin: 0 auto; /* Center the table horizontally */
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        th, td {
            background-color: #FFC0CB;
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #C0C0C0;
        }

        a:hover {
            color: red;
        }

        .edit-button, .delete-button {
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            font-weight: bold;
        }

        .edit-button {
            background-color: #34A56F; /* Green background color */
        }

        .edit-button:hover {
            background-color: #4CAF50;
        }

        .delete-button {
            background-color: #C34A2C; /* Red background color */
        }

        .delete-button:hover {
            background-color: #D32F2F;
        }

        .add-member-button-container,
.go-back-button-container {
    text-align: right;
    margin-top: 20px;
    margin:25px;
    display: flex; /* Display buttons in a flex container */
    justify-content: flex-end; /* Align buttons to the right */
    gap: 20px; /* Add spacing between the buttons */
}

.add-member-button,
.go-back-button {
    background-color: #007BFF; /* Blue background color */
    color: white;
    border: none;
    padding: 8px 12px;
    cursor: pointer;
}

.add-member-button:hover,
.go-back-button:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
    <h2>lender Details</h2>
    
    <table>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>email</th>
                <th>age</th>
                <th>ph</th>
                <th>qualification</th>
                <th>address</th>
                <th>accno</th>
                <th>branch</th>
                <th>salary</th>
            </tr>
            @foreach ($lenders as $lender)
            <tr>
                <td>{{ $lender->id}}</td>
                <td>{{ $lender->name}}</td>
                <td>{{ $lender->email}}</td>
                <td>{{ $lender->age}}</td>
                <td>{{ $lender->ph}}</td>
                <td>{{ $lender->qualification}}</td>
                <td>{{ $lender->address}}</td>
                <td>{{ $lender->accno}}</td>
                <td>{{ $lender->branch}}</td>
                <td>{{ $lender->salary}}</td>
                <td>
                    <a href="edit/{{ $lender->id }}">
                        <button class="edit-button">
                            <i class="icon">✏️</i> Edit
                            </button>
                    </a>
                </td>
                <td>
                    <a href="delete/{{ $lender->id }}">
                        <button class="delete-button">
                            <i class="icon">🗑️</i> Delete
                        </button>
                    </a>
                </td>
               

                
            </tr>
            @endforeach
        </tbody>
    </table>
    <div class="add-member-button-container">
    <a href="{{ route('insert_form1') }}">
         <button class="add-member-button">
            <i class="icon">➕</i> Add New Member
        </button>
    </a>
    </div>
    <div class="go-back-button-container">
    <a href="{{ route('landingpage') }}">
        <button class="go-back-button">
            <i class="icon">⬅️</i> Go Back
        </button>
    </a>
</div>

</body>
</html>

