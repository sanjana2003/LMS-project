<!DOCTYPE html>
<html>
<head>
    <title>Loan Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            background-image: url("https://png.pngtree.com/thumb_back/fw800/back_our/20190620/ourmid/pngtree-loan-poster-background-material-image_154549.jpg");
            margin: 0;
            padding: 0;
            background-attachment: fixed;
            background-repeat: none;

            
        }

        .header {
            background-color: gold;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .container {
            text-align: center;
            padding: 20px;
            
        }
        
        

        .section {
            display: inline-block;
            width: 50%;
            margin: 10px;
            padding: 10px;
            transition: transform .2s;
            background-color: #fff;
            box-shadow: 0px 0px 10px 0px #000;
        }
        .section:hover {
           -ms-transform: scale(1.2); /* IE 9 */
           -webkit-transform: scale(1.2); /* Safari 3-8 */
           transform: scale(1.2); 
        }

        .section h2 {
            margin-top: 0;
        }

        .section p {
            margin-bottom: 0;
        }
        .button {
            background-color: red;
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
        }
        .button:hover {
            background-color : red;
            color: red;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Welcome to the Loan Management System</h1>
    
  
            
        </div>
        <div class="section">
            <h2>Borrowers</h2>
            <p>Explore available plans and their details.</p>
            <a href="/borrower" class="button">Borrowers</a>

        </div>
        <div class="section">
            <h2>Lenders</h2>
            <p>Access loans lent information and records.</p>
            <a href="/lender" class="button">Lenders</a>

        
        </div>
        <div class="section">
            <h2>Loan</h2>
            <p>One step loan applicant key. With your borrower details we will file a loan application automatically</p>
            <a href="/loan" >Loan key</a>

        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\sanja\loan\resources\views/landingpage.blade.php ENDPATH**/ ?>