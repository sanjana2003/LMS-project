<!DOCTYPE html>
<html>
<head>
    <title>Borrower form | Add</title>>
    <style>
        .container {
        width: 400px;
        margin: 0 auto;
        padding: 55px;
        border: 1px solid #ccc;
        background-color: #f5f5f5;
        background-image: url("https://images.rawpixel.com/image_800/czNmcy1wcml2YXRlL3Jhd3BpeGVsX2ltYWdlcy93ZWJzaXRlX2NvbnRlbnQvbHIvdjk4M2JhdGNoMi0wMjYuanBn.jpg");
       }
    
    form {
        text-align: left;
    }
    
    h2 {
        text-align: center;
        margin-bottom: 20px;
    }
    
    label {
        display: block;
        margin-top: 10px;
        font-weight: bold;
    }
    
    
    
    .register-button {
        background-color: #1982c9;
        color: white;
        padding: 10px 20px;
        margin-top: 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    
    .container::after {
        content: "";
        display: table;
        clear: both;
    }
    
    
    
    
    </style>
</head>
<body>
    <div class="container">
        <form method ="post" action="/create">
            <?php echo csrf_field(); ?>
            <h2>Borrower Form</h2>

            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
             <br><br>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <br><br>

            <label for="age">Age:</label>
            <input type="text" id="age" name="age" required>
            <br><br>

            <label for="ph">Ph:</label>
            <input type="number" id="ph" name="ph" required>
            <br><br>

            <label for="qualification">qualification:</label>
            <input type="text" id="qualification" name="qualification" required>
            <br><br>

            <label for="address">adress:</label>
            <input type="text" id="address" name="address" required>
            <br><br>

            <label for="accno">Account No</label>
            <input type="number" id="accno" name="accno" required>
            <br><br>

            <label for="branch">Account Branch:</label>
            <input type="text" id="branch" name="branch" required>
            <br><br>

            <label for="salary">Income</label>
            <input type="number" id="salary" name="salary" required>
            <br><br>
            

            <button type="submit" name="Register" id="Register" class="register-button">Register</button>
   
           
        </form>
    </div>
</body>
</html><?php /**PATH C:\Users\sanja\loan\resources\views/insert_form.blade.php ENDPATH**/ ?>