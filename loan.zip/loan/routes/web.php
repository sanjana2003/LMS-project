<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\borrowcontroller;
use App\Http\Controllers\lendercontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/landingpage', function(){
    return view('landingpage');
});


Route::get('/borrower', [App\Http\Controllers\borrowcontroller::class, 'borrower_list']);

Route::get('/', [borrowcontroller::class, 'insert_form']);
Route::post('/create', [borrowcontroller::class, 'insert']);

Route::get('insert_form', [App\Http\Controllers\borrowcontroller::class, 'insert_form'])->name('insert_form');

Route::get('/landingpage', function(){
    return view('landingpage');
})->name('landingpage');

Route::get('view-borrower-records', [borrowcontroller::class, 'borrower_list']);

Route::get('edit/{id}', [borrowcontroller::class, 'edit']);
Route::post('edit/{id}', [borrowcontroller::class, 'update']);

Route::get('delete/{id}', [borrowcontroller::class, 'delete']);

Route::get('/lender', [App\Http\Controllers\lendercontroller::class, 'lender_list']);

Route::get('/', [lenderController::class, 'insert_form1']);
Route::post('/create1', [lendercontroller::class, 'insert1']);

Route::get('insert_form1', [App\Http\Controllers\lendercontroller::class, 'insert_form1'])->name('insert_form1');

Route::get('/landingpage', function(){
    return view('landingpage');
})->name('landingpage');

Route::get('view-lender-records', [lendercontroller::class, 'lender_list']);

Route::get('edit1/{id}', [lendercontroller::class, 'edit1']);
Route::post('edit1/{id}', [lendercontroller::class, 'update1']);

Route::get('delete1/{id}', [lendercontroller::class, 'delete1']);





