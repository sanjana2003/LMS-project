<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class lendercontroller extends Controller
{
    public function insert_form1(){
        return view('insert_form1');
    }
    public function insert1(Request $request, $id){
        $name = $request->input('name');
        $email = $request->input('email');
        $age = $request->input('age');
        $ph = $request->input('ph');
        $qualification  = $request->input('qualification');
        $address = $request->input('address');
        $accno= $request->input('accno');
        $branch = $request->input('branch');
        $salary= $request->input('salary');
        
        //insert operation

        DB::insert("insert into lender(name, email, age, ph, qualification, address, accno, branch , salary) values(?, ?, ?, ?, ?, ?, ?, ?, ?)", [$name, $email, $age, $ph, $qualification, $address, $accno , $branch, $salary , $id]);
        return 'Record inserted successfully! <a href="/view-lender-records">Click here to go back</a>';
    }

    public function lender_list(){
        $lenders = DB::select("select * from lender");
        return view('lender_list', ['lenders'=>$lenders]);
    }

    public function edit1($id){
        $lender = DB::select("select * from lender where id=?", [$id] );
        return view('lender_edit', ['lender'=>$lender]);
    }

    public function update1(Request $request, $id){
        $name = $request->input('name');
        $email = $request->input('email');
        $age = $request->input('age');
        $ph = $request->input('ph');
        $qualification  = $request->input('qualification');
        $address = $request->input('address');
        $accno= $request->input('accno');
        $branch = $request->input('branch');
        $salary= $request->input('salary');
        

        DB::update("update lender set name=?, email=?, age=?, ph=?, qualification=?, address=?, accno=?, branch=? , salary=? where id=?", [$name, $email, $age, $ph, $qualification, $address, $accno, $branch, $salary ,$id]);
        return 'Record updated Successfully! <a href="/view-lender-records">Click here to go back</a>';
    }
    public function delete1($id){
        DB::delete("delete from lender where id=?", [$id]);
        return 'Record deleted Successfully! <a href="/view-lender-records">Click here to go back</a>';
    }


}
