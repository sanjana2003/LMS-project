<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class borrowController extends Controller
{
    public function insert_form(){
        return view('insert_form');
    }
    public function insert(Request $request){
        $name = $request->input('name');
        $email = $request->input('email');
        $age = $request->input('age');
        $ph = $request->input('ph');
        $qualification  = $request->input('qualification');
        $address = $request->input('address');
        $accno= $request->input('accno');
        $branch = $request->input('branch');
        $salary= $request->input('salary');
        
        //insert operation

        DB::insert("insert into borrower(name, email, age, ph, qualification, address, accno, branch, salary) values(?, ?, ?, ?, ?, ?, ?, ?, ?)", [$name, $email, $age, $ph, $qualification, $address , $accno, $branch, $salary]);
        return 'Record inserted successfully! <a href="/view-borrower-records">Click here to go back</a>';
    }

    public function borrower_list(){
        $borrowers = DB::select("select * from borrower");
        return view('borrower_list', ['borrowers'=>$borrowers]);
    }

    public function edit($id){
        $borrower = DB::select("select * from borrower where id=?", [$id] );
        return view('borrower_edit', ['borrower'=>$borrower]);
    }

    public function update(Request $request, $id){
        $name = $request->input('name');
        $email = $request->input('email');
        $age = $request->input('age');
        $ph = $request->input('ph');
        $qualification  = $request->input('qualification');
        $address = $request->input('address');
        $accno= $request->input('accno');
        $branch = $request->input('branch');
        $salary= $request->input('salary');

        DB::update("update borrower set name=?, email=?, age=?, ph=?, qualification=?, address=?,  accno=?, branch=?, salary=? where id=?", [$name, $email, $age, $ph, $qualification, $address ,$accno, $branch, $salary, $id]);
        return 'Record updated Successfully! <a href="/view-borrower-records">Click here to go back</a>';
    }
    public function delete($id){
        DB::delete("delete from borrower where id=?", [$id]);
        return 'Record deleted Successfully! <a href="/view-borrower-records">Click here to go back</a>';
    }

}